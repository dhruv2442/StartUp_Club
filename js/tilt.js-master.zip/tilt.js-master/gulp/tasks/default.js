/* default task */

/**
 * Plugins
 */
var gulp = require('gulp');

/**
 * Tasks
 */
gulp.task('default', [
  'scss'
]);
